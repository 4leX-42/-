/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aandreu <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/27 15:55:16 by aandreu           #+#    #+#             */
/*   Updated: 2024/02/27 16:48:11 by aandreu          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
/*
#include <stdio.h>

int main() {
  int a = 0;
  int *ptr1 = &a;
  int **ptr2 = &ptr1;
  int ***ptr3 = &ptr2;
  int ****ptr4 = &ptr3;
  int *****ptr5 = &ptr4;
  int ******ptr6 = &ptr5;
  int *******ptr7 = &ptr6;
  int ********ptr8 = &ptr7;
  int *********ptr9 = &ptr8;

  ft_ultimate_ft(ptr9);

  printf("Valor de a: %d\n", a);

  return 0;
}
*/
